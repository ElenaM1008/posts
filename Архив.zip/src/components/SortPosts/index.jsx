import React, { useState } from "react";
import * as SC from './styles'
import { useDispatch, useSelector } from "react-redux";
import { sortPosts } from "../../redux/slices/postsSlices";

export const SortPosts = () => {
	const { sortValue } = useSelector((state) => state.posts.posts)
	const [value, setValue] = useState(sortValue)

	const dispatch = useDispatch()

	const onSort = (e) => {
		setValue((e.target.value))
		dispatch(sortPosts(e.target.value))
	}
	
	return (
		<>
			<span>Сортировать </span>
			<SC.Sort onChange={onSort} value={value}>
				<option value='default'> по добавлению (from NEW to OLD)</option>
				<option value='name'> по названию (from A to Z)</option>
			</SC.Sort>
		</>
	)
}