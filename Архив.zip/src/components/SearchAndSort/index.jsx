import React, { useState } from "react"
import { Input } from "../ui/Input"
import { Button } from "../ui/Button"
import * as SC from './styles'
import { useDispatch, useSelector } from "react-redux"
import { filteredSearch, sortPosts } from '../../redux/slices/postsSlices'

export const SearchAndSort = () => {
	const { sortValue } = useSelector((state) => state.posts.posts)
	const [value, setValue] = useState(sortValue)
	const [searchTerm, setSearchTerm] = useState('')
	const dispatch = useDispatch()

	const changeSearchTerm = (e) => {
		setSearchTerm(e.target.value)
	}

	const handleSearch = () => {
		dispatch(filteredSearch(searchTerm))
		dispatch(sortPosts(value))
	}

	const onSort = (e) => {
		setValue((e.target.value))
		dispatch(sortPosts(e.target.value))
	}
	
	return (
		<>
			<SC.Search>
				<Input
					placeholder="Search"
					onChange={changeSearchTerm}
					value={searchTerm} />
				<Button onClick={handleSearch}>Найти</Button>
			</SC.Search>
			<span>Сортировать </span>
			<SC.Sort onChange={onSort} value={value}>
				<option value='default'> по добавлению (from NEW to OLD)</option>
				<option value='name'> по названию (from A to Z)</option>
			</SC.Sort>
		</>
	)
}