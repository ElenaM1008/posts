import styled from "styled-components";

export const Search = styled.div`
   display:flex;
   gap:10px;
`

export const Sort = styled.select`
	width: '262px';
	margin-top:20px;
	border:none;
	color: #778899;
	font-weight:bold;
	font-size:16px;
`