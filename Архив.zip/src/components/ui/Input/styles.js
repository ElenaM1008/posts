import styled from "styled-components";

export const Input = styled.input`
   width: 100%;
	outline: none;
	border: 1px solid #282c34; 
`