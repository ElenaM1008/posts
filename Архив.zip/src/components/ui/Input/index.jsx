import React from "react";
import * as SC from './styles'

export const Input = (props) => <SC.Input {...props} />