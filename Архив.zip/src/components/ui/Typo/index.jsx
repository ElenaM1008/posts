import React from "react";
import * as SC from './styles'

export const Typo = ({ children }) => <SC.Title>{children}</SC.Title>