import styled from "styled-components";

export const Title = styled.h1`
   color:black;
	text-align:center;
`