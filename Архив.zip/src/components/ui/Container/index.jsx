import React from "react";
import * as SC from './styles'

export const Container = ({ children }) => <SC.Container>{children}</SC.Container>