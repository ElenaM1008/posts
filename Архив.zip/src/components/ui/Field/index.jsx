import React from "react";

export const Field = ({children, ...rest}) => <div {...rest}>{children}</div>